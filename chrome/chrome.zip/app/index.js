var DEBUG =false;
var DEBUG_SERVER = "http://localhost:9000/";

var SERVER = window.SERVER = DEBUG ? DEBUG_SERVER : "http://pinterest.likeus.cloudbees.net/";
window.likeus_path = function (path) {
    return window.SERVER + path;
}
var templates = {}
window.likeus_tpl = function (name, callback) {
    var template = templates[name];
    if (!template) {
        $.get(likeus_path("template/" + name), function (html) {
            templates[name] = html;
            callback(html)
        });
    } else {
        callback(template);
    }

}

window.likeus_timestamp = function () {
    var date = new Date(),
        year = date.getFullYear(),
        month = date.getMonth() + 1,
        day = date.getDate(),
        hour = date.getHours(),
        minute = date.getMinutes(),
        second = date.getSeconds();

    var pad = function (n) {
        return n < 10 ? '0' + n : String(n);
    };

    return pad(year) + '-' + pad(month) + '-' + pad(day) + ' ' +
        pad(hour) + ':' + pad(minute) + ':' + pad(second);
}
Logging = {
    LOG_LEVELS: {
        error: 3,
        warn: 2,
        info: 1,
        debug: 0
    },

    logLevel: DEBUG ? 'debug' : 'error',

    log: function (messageArgs, level) {


        var levels = Logging.LOG_LEVELS;
        if (levels[Logging.logLevel] > levels[level]) return;

        var messageArgs = Array.prototype.slice.apply(messageArgs),
            banner = ' [' + level.toUpperCase() + '] [Likeus',
            klass = this.className,

            message = messageArgs.shift().replace(/\?/g, function () {
                try {
                    return JSON.stringify(messageArgs.shift());
                } catch (e) {
                    return '[Object]';
                }
            });


        if (klass) banner += '.' + klass;
        banner += '] ';

        console.log(likeus_timestamp() + banner + message);
    }
};

$.each(Logging.LOG_LEVELS, function (level, value) {
    Logging[level] = function () {
        this.log(arguments, level);
    };
});
$.extend(Backbone.View.prototype, Logging);

window.likeus_script = function (url, attrs, callback) {
    if (typeof attr == "function") {
        callback = attrs;
        attrs = {}
    }
    var s = document.createElement('script');
    s.src = url;
    if (attrs) {
        for (var attr in attrs) {
            s.setAttribute(attr, attrs[attr]);
        }
    }
    if (callback) {
        s.onload = callback;
    }

    (document.head || document.documentElement).appendChild(s);
}
var div = document.createElement("div");
div.setAttribute("id", "likeus-config");
div.style.display = "none";
div.setAttribute("data-config", JSON.stringify({
    DEBUG: DEBUG,
    SERVER: SERVER,
    PROFILE: $(".UserMenu .usernameLink").attr("href").replace("/", "")
}))
document.getElementsByTagName('body')[0].appendChild(div);
$("body").addClass("likeus");

likeus_script(chrome.extension.getURL("app/inject/support.js"));
likeus_script(chrome.extension.getURL("app/inject/ajax_hooks.js"));

//http://stackoverflow.com/questions/9602022/chrome-extension-retrieving-gmails-original-message
